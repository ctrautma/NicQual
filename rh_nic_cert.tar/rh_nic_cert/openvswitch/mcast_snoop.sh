#!/bin/bash
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   runtest.sh of /kernel/networking/openvswitch/mcast_snoop
#   Author: Junhan Yan <juyan@redhat.com>
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   Copyright (c) 2017 Red Hat, Inc.
#
#   This copyrighted material is made available to anyone wishing
#   to use, modify, copy, or redistribute it subject to the terms
#   and conditions of the GNU General Public License version 2.
#
#   This program is distributed in the hope that it will be
#   useful, but WITHOUT ANY WARRANTY; without even the implied
#   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#   PURPOSE. See the GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public
#   License along with this program; if not, write to the Free
#   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
#   Boston, MA 02110-1301, USA.
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PACKAGE="mcast_snoop"

source env.sh

#----------------------------------------------------------

# this will be called before and after the test
cleanup_env()
{

	# echo "remove any bridge if exist"
	brctl show | sed -n 2~1p | awk '/^[[:alpha:]]/ {
		system("ip link set "$1" down")
		sleep 2
		system("brctl delbr "$1)
	}'

	# echo "remove any vxlan if exist"
	ip -d link show | grep "\bvxlan\b" -B 2 | sed -n 1~3p | awk '{
		gsub(":","")
		system ("ip link del "$2)
	}'

	# echo "remove any gre if exist"
	ip -d link show | grep "\bgretap\b\|\bip6gretap\b" -B 2 | \
		sed -n 1~3p | awk '($2 ~ /[[:alnum:]]+@[[:alnum:]]+/) {
		split($2,gre,"@")
		system("ip link del "gre[1])
	}'

	# echo "remove any VM if exist"
	virsh list --all | sed -n 3~1p | awk '/[[:alpha:]]+/ {
		if ($3 == "running") {
			system("virsh shutdown "$2)
			sleep 2
			system("virsh destroy "$2)
		}
		system("virsh undefine --managed-save --snapshots-metadata --remove-all-storage "$2" &>/dev/null")
	}'
	# echo "remove any vnet definition if exist"
	virsh net-list --all | sed -n 3~1p | awk '/[[:alnum:]]+/ {
		system("virsh net-destroy "$1)
		sleep 2
		system("virsh net-undefine "$1)
	}'

	#echo "remove any netns if exist"
	ip netns list | awk '{ system("ip netns del "$1) }'

	ovs-vsctl list bridge 2>/dev/null | grep name | awk '{
		system("ovs-vsctl --if-exist del-br "$3" &>/dev/null")
	}'
	systemctl stop ovn-controller &>/dev/null
	systemctl stop ovn-northd &>/dev/null
	systemctl stop openvswitch &>/dev/null
	sleep 5
	rm -rf /etc/openvswitch/*.db
	rm -rf /var/lib/openvswitch/*
	sync

}

# set up env for ovs mcast snooping tests
setup_env()
{
	# stop security features
	if (($rhel_version >= 7)); then
		sed -i 's/BOOTPROTO=.*$/BOOTPROTO=none/g' /etc/sysconfig/network-scripts/ifcfg-${nic_test}
		sed -i 's/NM_CONTROLLED=.*$/NM_CONTROLLED=no/g' /etc/sysconfig/network-scripts/ifcfg-${nic_test}
		sed -i 's/IPV6_AUTOCONF=.*$/IPV6_AUTOCONF=no/g' /etc/sysconfig/network-scripts/ifcfg-${nic_test}
	fi
	iptables -F
	ip6tables -F

	if (($rhel_version <= 6)); then
		service openvswitch restart
	else
		systemctl restart openvswitch
	fi
	sleep 10

	ip link set $nic_test up
	ip addr flush dev $nic_test

	if i_am_server; then
		sync_set client test_start
		# prepare openvswitch
		ovs-vsctl add-br $ovs_br
		ip link set $ovs_br up
		ovs-vsctl add-port $ovs_br $nic_test
		
		# prepare namespace
		ip link add g1_veth0 type veth peer name g1_veth1
		ip link set g1_veth0 up
		ip link set g1_veth1 up

		ip link add g2_veth0 type veth peer name g2_veth1
		ip link set g2_veth0 up
		ip link set g2_veth1 up
		
		
		# prepare namespace 
		ip netns add g1
		ip link set g1_veth0 netns g1
		ip netns exec g1 ip link set g1_veth0 up
		ip netns exec g1 ip route add 239.1.1.1 dev g1_veth0
		ip netns exec g1 ip addr add $ipaddr_test_veth1/24 dev g1_veth0

		ip netns add g2
		ip link set g2_veth0 netns g2
		ip netns exec g2 ip link set g2_veth0 up
		ip netns exec g2 ip route add 239.1.1.1 dev g2_veth0
		ip netns exec g2 ip addr add $ipaddr_test_veth2/24 dev g2_veth0
		
		# prepare vm
        	pushd "/var/lib/libvirt/images/" 1>/dev/null
        	wget -nv -N $IMG_GUEST
        	cp --remove-destination $(basename $IMG_GUEST) vm1.qcow2
        	cp --remove-destination $(basename $IMG_GUEST) vm2.qcow2
        	popd 1>/dev/null

       		# define default vnet
        	virsh net-define /usr/share/libvirt/networks/default.xml
        	virsh net-start default
        	virsh net-autostart default

        	cat <<-EOF > ovs_vnet_vm1.xml
			<network>
			<name>vnet_vm1</name>
			<forward mode='bridge'/>
			<bridge name='ovsbr0' />
			<virtualport type='openvswitch'>
			</virtualport>
			</network>
		EOF
        	virsh net-define ovs_vnet_vm1.xml
        	virsh net-start vnet_vm1
        	virsh net-autostart vnet_vm1
        	virt-install \
			--name vm1 \
			--vcpus=2 \
			--ram=2048 \
			--disk path=/var/lib/libvirt/images/vm1.qcow2,device=disk,bus=virtio,format=qcow2 \
			--network bridge=virbr0,model=virtio,mac="${mac4vm}:01" \
			--network network=vnet_vm1,model=virtio,mac="${mac4vm}:02" \
			--boot hd \
			--accelerate \
			--graphics vnc,listen=0.0.0.0 \
			--force \
			--os-type=linux \
			--noautoconsol

        	cat <<-EOF > ovs_vnet_vm2.xml
			<network>
			<name>vnet_vm2</name>
			<forward mode='bridge'/>
			<bridge name='ovsbr0' />
			<virtualport type='openvswitch'>
			</virtualport>
			</network>
		EOF
        	virsh net-define ovs_vnet_vm2.xml
        	virsh net-start vnet_vm2
        	virsh net-autostart vnet_vm2
        	virt-install \
			--name vm2 \
			--vcpus=2 \
			--ram=2048 \
			--disk path=/var/lib/libvirt/images/vm2.qcow2,device=disk,bus=virtio,format=qcow2 \
			--network bridge=virbr0,model=virtio,mac="${mac4vm}:11" \
			--network network=vnet_vm2,model=virtio,mac="${mac4vm}:12" \
			--boot hd \
			--accelerate \
			--graphics vnc,listen=0.0.0.0 \
			--force \
			--os-type=linux \
			--noautoconsol

	       	# wait VM bootup
       		sleep 30
		if [ "$UPDATE_VM" = "yes" ]; then
        		vmsh run_cmd vm1 \
        		vmsh run_cmd vm2 \
        		# update VM kernel to the same one as host
        		local update_kernel="rpm -ivh --nodeps --force $RPM_KERNEL"
        		vmsh run_cmd vm1 "$update_kernel"
        		virsh reboot vm1
        		vmsh run_cmd vm2 "$update_kernel"
        		virsh reboot vm2
		fi

		if (($rhel_version >= 7)); then
                vmsh run_cmd vm1 "systemctl stop NetworkManager"
		fi

		local cmd_vm1=(
		{iptables -F}
		{ip6tables -F}
		{setenforce 1}
		{ip link set dev ${get_iface_vm1} down}
		{ip link set dev ${get_iface_vm1} up}
		{rpm -q iperf \|\| yum -y install $IPERF_RPM}
		{ip route add 239.1.1.1 dev ${get_iface_vm1}}
		) 
		 
		local cmd_vm2=(
		{iptables -F}
		{ip6tables -F}
		{setenforce 1}
		{ip link set dev ${get_iface_vm2} down}
		{ip link set dev ${get_iface_vm2} up}
		{rpm -q iperf \|\| yum -y install $IPERF_RPM}
		{ip route add 239.1.1.1 dev ${get_iface_vm2}}
		) 
		 
		vmsh cmd_set vm1 "${cmd_vm1[*]}"
		vmsh cmd_set vm2 "${cmd_vm2[*]}"

		# add ip addr to ovs
		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br
		sync_wait client test_end
	else
		sync_wait server test_start
		ip addr add $ipaddr_test/24 dev $nic_test
		ip addr add $ip6addr_test/64 dev $nic_test
		sync_set server test_end
	fi

}

#----------------------------------------------------------
# tests

ovs_test_mcast_snooping_disable()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1
		ovs-vsctl add-port $ovs_br g2_veth1

		# disable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=false && echo "Attempt to disable mcast snooping failed"

		sync_wait client test_start
		# tcpdump
		timeout 10 ip netns exec g1 tcpdump -i g1_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" ||((result+=1))
		
		timeout 10 ip netns exec g2 tcpdump -i g2_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" ||((result+=1))

		sync_set client test_end
		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1
		ovs-vsctl del-port $ovs_br g2_veth1

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start
		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_enable()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1
		ovs-vsctl add-port $ovs_br g2_veth1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"
		
		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true

		sync_wait client test_start
		# tcpdump
		timeout 10 ip netns exec g1 tcpdump -i g1_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" && ((result+=1))
		
		timeout 10 ip netns exec g2 tcpdump -i g2_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" && ((result+=1))

		sync_set client test_end

		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1
		ovs-vsctl del-port $ovs_br g2_veth1

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_enable_join()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1
		ovs-vsctl add-port $ovs_br g2_veth1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"
		
		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		
		#====================
		#bug 1456358
		ip netns exec g1 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &
		ovs-vsctl del-port g1_veth1  
		ovs-appctl mdb/show $ovs_br
		pkill -9 iperf
		#====================

		ovs-vsctl add-port $ovs_br g1_veth1
		#join the g1 to the mcast group but g2 not
		ip netns exec g1 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &
		 
		sync_wait client test_start
		# tcpdump
		timeout 10 ip netns exec g1 tcpdump -i g1_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" ||((result+=1))
		
		timeout 10 ip netns exec g2 tcpdump -i g2_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" && ((result+=1))

		sync_set client test_end
		pkill -9 tcpdump			 
		pkill -9 iperf			 
		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1
		ovs-vsctl del-port $ovs_br g2_veth1

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start


		sync_wait server test_end
		pkill -9 iperf
	fi


	return $result

}

ovs_test_mcast_snooping_enable_leave()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"
		
		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		
		#join the g1 to the mcast group but g2 not
		ip netns exec g1 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &
		 
		sync_wait client test_start
		# tcpdump 
		if timeout 10 ip netns exec g1 tcpdump -i g1_veth0 -c 1 -nn -l "src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999"; then
			pkill -9 iperf
			sleep 2
			timeout 10 ip netns exec g1 tcpdump -i g1_veth0 -c 1 -nn -l\
			"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" && ((result+=1))
		else
			 ((result+=1))
		fi

		sync_set client test_end
		pkill -9 tcpdump
		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf	
	fi

	return $result
}

ovs_test_mcast_snooping_enable_vlan()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1
		ovs-vsctl add-port $ovs_br g2_veth1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"
		
		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
	
		#====================
		#cover bug 1456358
		ovs-vsctl set Port g1_veth1 tag=3
		ip netns exec g1 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &
		ovs-vsctl set Port g1_veth1 tag=2           
		if ovs-appctl mdb/show $ovs_br|grep 239.1.1.1; then
			((result+=1))
			echo 'Change vlan but does not change on mdb'
		fi
		pkill -9 iperf
		#====================

		ovs-vsctl set Port g1_veth1 tag=3
		ovs-vsctl set Port g2_veth1 tag=30
		ovs-vsctl set Port $nic_test vlan_mode=trunk trunks=3
			
		#join the g1 and g2 to the mcast group
		ip netns exec g1 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &
		ip netns exec g2 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &
		 
		sync_wait client test_start
		# tcpdump
		timeout 10 ip netns exec g1 tcpdump -i g1_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999" ||((result+=1))
		
		timeout 10 ip netns exec g2 tcpdump -i g2_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999" && ((result+=1))
		
		sync_set client test_end
		pkill -9 tcpdump
		pkill -9 iperf
		ovs-vsctl clear Port $nic_test trunks vlan_mode
			 
		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1
		ovs-vsctl del-port $ovs_br g2_veth1

	else
		ip link add link $nic_test name vlan3 type vlan id 3
		ip link set vlan3 up
		ip addr add $ipaddr_test_vlan/24 dev vlan3
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test_vlan -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
		ip link del vlan3
	fi

	return $result
}

_ovs_test_mcast_snooping_aging_time()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"
		
		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		 
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-aging-time=20
		ip netns exec g1 iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &

		sync_set client test_start
		# tcpdump 
		ip netns exec g1 timeout 10 tcpdump -i g1_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" \

		if (( $? != 0 )); then
			 ((result+=1))
		else
			sleep 20 
			if ip netns exec g1 timeout 10 tcpdump -i g1_veth0 -c 1 -nn -l "src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999"; then
			 	((result+=1))
			fi

		fi
		sync_set client test_end
		pkill -9 tcpdump
		pkill -9 iperf
		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-aging-time=300

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_wait server test_start


		sync_wait server test_end
		pkill -9 iperf	
	fi

	return $result
}

_ovs_test_mcast_snooping_table_size()
{
	local result=0
	pkill -9 iperf
	pkill -9 iperf

	if i_am_server; then
		# add veth to ovs
		ovs-vsctl add-port $ovs_br g1_veth1
		ovs-vsctl add-port $ovs_br g2_veth1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"
		
		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		sleep 2	
			
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-table-size=1
		sleep 2	

		#join the g1 to the mcast group
		ip netns exec g1 join_group -f 4 -i g1_veth0 -g 239.1.1.1 &
		 
		sync_set client test_start
		# tcpdump
		ip netns exec g1 timeout 10 tcpdump -i g1_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" \
		
		#join the g2 to the mcast group
		ip netns exec g2 join_group -f 4 -i g2_veth0 -g 239.1.1.1 &

		ip netns exec g2 timeout 10 tcpdump -i g2_veth0 -c 1 -nn -l \
		"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999" \

		echo "g1:"
		cat /tmp/tcpdump_g1.asc
		echo "g2:"
		cat /tmp/tcpdump_g2.asc

		grep -q "239.1.1.1.9999: UDP" /tmp/tcpdump_g1.asc
		if (( $? != 0 )); then
			((result+=1))
		fi
		grep -q "239.1.1.1.9999: UDP" /tmp/tcpdump_g2.asc
		if (( $? == 0 )); then
			((result+=1))
		fi
		rm -f /tmp/tcpdump_g2.asc /tmp/tcpdump_g1.asc	 
		
		pkill -9 tcpdump
		pkill -9 iperf
			 
		# delete veth from ovs
		ovs-vsctl del-port $ovs_br g1_veth1
		ovs-vsctl del-port $ovs_br g2_veth1

		sync_set client test_end
	else
		msend -f4 239.1.1.1 9999 -I $nic_test &
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_wait server test_start


		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_disable_vm()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
		# add veth to ovs
		ovs-vsctl add-port $ovs_br $tap1
		ovs-vsctl add-port $ovs_br $tap2

		# disable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=false && echo "Attempt to disable mcast snooping successfully"

		sync_wait client test_start
		# tcpdump
		vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\"" ||((result+=1))
		
		vmsh run_cmd vm2 "timeout 10  tcpdump -i $get_iface_vm2 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\"" ||((result+=1))

		sync_set client test_end
		# delete vnet from ovs
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $tap2

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_enable_vm()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
		# add veth to ovs
		ovs-vsctl add-port $ovs_br $tap1
		ovs-vsctl add-port $ovs_br $tap2

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"

		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
	
		sync_wait client test_start
		# tcpdump
		vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\"" && ((result+=1))
		
		vmsh run_cmd vm2 "timeout 10  tcpdump -i $get_iface_vm2 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\"" && ((result+=1))

		sync_set client test_end
		# delete vnet from ovs
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $tap2

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_enable_join_vm()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
		# add veth to ovs
		ovs-vsctl add-port $ovs_br $tap1
		ovs-vsctl add-port $ovs_br $tap2

		#enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"

		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		
		# join vm1 to the mcast group
		vmsh run_cmd vm1 "iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &"

		sync_wait client test_start
		# tcpdump
		vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\""  ||((result+=1))
		
		vmsh run_cmd vm2 "timeout 10  tcpdump -i $get_iface_vm2 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\"" && ((result+=1))

		sync_set client test_end
		# delete vnet from ovs
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $tap2

		vmsh run_cmd vm1 "pkill -9 iperf"
	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_enable_leave_vm()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		vmsh run_cmd vm1 "pkill -9 iperf"
		# add vm to ovs
		ovs-vsctl add-port $ovs_br $tap1

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"

		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		
		# join vm1 to the mcast group
		vmsh run_cmd vm1 "iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &"

		sync_wait client test_start
		# tcpdump
		
		if vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\""; then
			vmsh run_cmd vm1 "pkill -9 iperf"
			sleep 2
			vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_peer and dst host 239.1.1.1 and udp port 9999\"" && ((result+=1))
			
		else
			 ((result+=1))
		fi

		sync_set client test_end
		# delete vnet from ovs
		ovs-vsctl del-port $ovs_br $tap1

	else
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
	fi

	return $result
}

ovs_test_mcast_snooping_enable_vlan_diff()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
		# add vm to ovs
		ovs-vsctl add-port $ovs_br $tap1
		ovs-vsctl add-port $ovs_br $tap2

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"

		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		
		ovs-vsctl set Port $tap1 tag=3
		ovs-vsctl set Port $tap2 tag=30
		ovs-vsctl set Port $nic_test vlan_mode=trunk trunks=3
		
		# join vm1 and vm2 to the mcast group
		vmsh run_cmd vm1 "iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &"
		vmsh run_cmd vm2 "iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &"

		sync_wait client test_start
		# tcpdump
		vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999\"" ||((result+=1))
		
		vmsh run_cmd vm2 "timeout 10  tcpdump -i $get_iface_vm2 -c 1 -nn -l \"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999\"" && ((result+=1))

		sync_set client test_end
		ovs-vsctl clear Port $tap1 tag
		ovs-vsctl clear Port $tap2 tag
		ovs-vsctl clear Port $nic_test trunks vlan_mode
		# delete vnet from ovs
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $tap2

		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
	else
		ip link add link $nic_test name vlan3 type vlan id 3
		ip link set vlan3 up
		ip addr add $ipaddr_test_vlan/24 dev vlan3
		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test_vlan -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
		ip link del vlan3
	fi

	return $result
}

#Add two vm into the same vlan, vm1 join the mcast group but vm2 not, 
#vm1 should reseive the mcast packtets.vm2 can't reseive the packets.
#Then vm1 leave current vlan can't reseive the packets either.
#After leaving, vm1 join the another vlan,
#vm1 can reseive the mcast packets from the another vlan.
ovs_test_mcast_snooping_enable_vlan_vm()
{
	local result=0
	pkill -9 iperf

	if i_am_server; then
		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
		# add vm to ovs
		ovs-vsctl add-port $ovs_br $tap1
		ovs-vsctl add-port $ovs_br $tap2

		# enable mcast_snooping
		ovs-vsctl set Bridge $ovs_br mcast_snooping_enable=true && echo "Attempt to enable mcast snooping successfully"

		# disable the flood of unregistered packets
		ovs-vsctl set Bridge $ovs_br \
		other_config:mcast-snooping-disable-flood-unregistered=true
		
		ovs-vsctl set Port $tap1 tag=3
		ovs-vsctl set Port $tap2 tag=3
		ovs-vsctl set Port $nic_test vlan_mode=trunk trunks=3,30
		
		# join vm1 to the mcast group
		vmsh run_cmd vm1 "iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &"

		sync_wait client test_start
		# tcpdump
		
		vmsh run_cmd vm2 "timeout 10  tcpdump -i $get_iface_vm2 -c 1 -nn -l \"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999\"" && ((result+=1))

		vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999\"" 

		if (( $? != 0 )); then
			 ((result+=1))
		else
			vmsh run_cmd vm1 "pkill -9 iperf"
			sleep 2
			
			if vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999\"" ; then
			 	((result+=1))
			else
				sync_set client test_end

				ovs-vsctl set Port $tap1 tag=30
				vmsh run_cmd vm1 "iperf -s -u -B 239.1.1.1 -i 1 -p 9999 &"
				sync_wait client test_start
				vmsh run_cmd vm1 "timeout 10  tcpdump -i $get_iface_vm1 -c 1 -nn -l \"src host $ipaddr_test_vlan_peer and dst host 239.1.1.1 and udp port 9999\""  ||((result+=1))
			fi
		fi

		sync_set client test_end
		ovs-vsctl clear Port $tap1 tag
		ovs-vsctl clear Port $tap2 tag
		ovs-vsctl clear Port $nic_test trunks vlan_mode
		# delete vnet from ovs
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $tap2

		vmsh run_cmd vm1 "pkill -9 iperf"
		vmsh run_cmd vm2 "pkill -9 iperf"
	else
		ip link add link $nic_test name vlan3 type vlan id 3
		ip link set vlan3 up
		ip addr add $ipaddr_test_vlan/24 dev vlan3

		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test_vlan -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
		ip link del vlan3

		ip link add link $nic_test name vlan30 type vlan id 30
		ip link set vlan30 up
		ip addr add $ipaddr_test_vlan/24 dev vlan30

		iperf -c 239.1.1.1 -u -T 1 -t 500 -i 1 -B $ipaddr_test_vlan -p 9999 &
		sync_set server test_start

		sync_wait server test_end
		pkill -9 iperf
		ip link del vlan30

	fi

	return $result
}

# main

rlJournalStart

rlPhaseStartSetup

# cleanup the dirty env for the case after other tests on the required hosts
if [ "$OVS_SKIP_SETUP_ENV" != "yes" ]; then
	rlRun "cleanup_env"
fi

rlRun "get_address"

get_iface_vm1="\$(ip link show|grep -i $mac4vm:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
get_iface_vm2="\$(ip link show|grep -i $mac4vm:12 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

if [ "$OVS_SKIP_SETUP_ENV" != "yes" ]; then
	rlRun "setup_env"
fi

tap1=$(ip link show|grep -i $(expr substr ${mac_g1} 4 ${#mac_g1}) -B 1|awk '/^[0-9]+/ {gsub(":","",$2); print $2}')
tap2=$(ip link show|grep -i $(expr substr ${mac_g2} 4 ${#mac_g2}) -B 1|awk '/^[0-9]+/ {gsub(":","",$2); print $2}')

ovs-vsctl del-port $tap1
ovs-vsctl del-port $tap2

rlPhaseEnd

if [ "$OVS_TOPO" = "setup" ]; then
	rlJournalPrintText
	rlJournalEnd
	exit 0
fi
my_run_test "ovs_test_mcast_snooping_disable" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_join" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_leave" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_vlan" "jumbo_test=no"
my_run_test "_ovs_test_mcast_snooping_aging_time" "jumbo_test=no"

my_run_test "ovs_test_mcast_snooping_disable_vm" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_vm" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_join_vm" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_leave_vm" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_vlan_diff" "jumbo_test=no"
my_run_test "ovs_test_mcast_snooping_enable_vlan_vm" "jumbo_test=no"

if [ -f ovs_mcast_ipv6.sh ]; then
	source ovs_mcast_ipv6.sh
fi

if [ "$OVS_SKIP_SETUP_ENV" != "yes" ]; then
	rlPhaseStartCleanup
	rlRun "cleanup_env"
	rlPhaseEnd
fi

if i_am_server; then
	rhts_submit_log -l $result_file
fi

rlJournalPrintText
rlJournalEnd
