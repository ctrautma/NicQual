#!/bin/bash - 

#####################################
# Settings for test
#

# root directory for the test suite
# may be set manually
RH_NIC_CERT_ROOT=${RH_NIC_CERT_ROOT:-"$(dirname $(readlink -f $0))"}

#
# The physical connection is like
#
# +---------+                +--------+               +---------+
# |         | p5p1     e1/9  |        |               |         |
# |         +----------------+        | e1/11    p5p1 |         |
# | CLIENTS |                | Switch +---------------+ SERVERS |
# |         +----------------+        |               |         |
# |         | p5p2     e1/10 |        |               |         |
# +----+----+                +----+---+               +----+----+
#      |                          |                        |
#      +--------------------------+------------------------+
#                                 |
#                            To Internet
#
#
# + Internet connections is used to install needed packages
#   in the test from Internet
#   For the needed packages, please see env.sh in each test module
#

# hostname for the machines
# The name must be the same as shown by linux command hostname
# and the names for CLIENTS and SERVERS must not be the same
CLIENTS=${CLIENTS:-"dell-per730-04.rhts.eng.pek2.redhat.com"}
SERVERS=${SERVERS:-"dell-per730-05.rhts.eng.pek2.redhat.com"}

# NICs on the machines used to run test
# bonding test needs two interfaces on CLIENTS side
NIC_CLIENT=${NIC_CLIENT:-"p5p1 p5p2"}
NIC_SERVER=${NIC_SERVER:-"p5p1"}

# switch name which is defined by $SWITCH_LIST in bin/swlist
SW_NAME=${SW_NAME:-'5010'}
# switch ports connected to $NIC_CLIENT in the same order as in $NIC_CLIENT
SW_PORT_CLIENT=${SW_PORT_CLIENT:-"Eth1/9 Eth1/10"}
# switch ports connected to $NIC_SERVER in the same order as in $NIC_SERVER
SW_PORT_SERVER=${SW_PORT_SERVER:-"Eth1/11"}

# VM image for test
IMG_GUEST=${IMG_GUEST:-"http://netqe-bj.usersys.redhat.com/share/vms/rhel7.4.qcow2"}

# RPM packages for test
SRC_NETPERF=${SRC_NETPERF:-"http://netqe-bj.usersys.redhat.com/share/tools/netperf-20160222.tar.bz2"}
RPM_KERNEL=${RPM_KERNEL:-""}
IPERF_RPM=${IPERF_RPM:-"https://iperf.fr/download/fedora/iperf-2.0.8-2.fc23.x86_64.rpm"}

# setting for SELinux
SETENFORCE=${SETENFORCE:-'Permissive'}

# Test selecion
#
# QE_SKIP_TEST has a higher priority than QE_TEST, that is,
# If a test is listed in QE_SKIP_TEST, the test will be skipped
# even it's also listed in QE_TEST
#
QE_SKIP_TEST=${QE_SKIP_TEST:-''}
QE_TEST=${QE_TEST:-'ovs_all'}
BONDING_TEST="ovs_test_bond_active_backup ovs_test_bond_set_active_slave ovs_test_bond_lacp_active ovs_test_bond_lacp_passive ovs_test_bond_balance_slb ovs_test_bond_balance_tcp"

# settings for OVS
RPM_OVS="http://download-node-02.eng.bos.redhat.com/brewroot/packages/openvswitch/2.7.2/10.git20170914.el7fdp/x86_64/openvswitch-2.7.2-10.git20170914.el7fdp.x86_64.rpm"

#####################################
# Run test automatically from here
#
# No need to change below this line

if (($(wc -w <<< $SW_PORT_CLIENT) != $(wc -w <<< $NIC_CLIENT) ||
	$(wc -w <<< $SW_PORT_SERVER) != $(wc -w <<< $NIC_SERVER)))
then
	echo ERROR configuration for NIC or SW_PORT
	echo NIC_CLIENT=$NIC_CLIENT
	echo NIC_SERVER=$NIC_SERVER
	echo SW_PORT_CLIENT=$SW_PORT_CLIENT
	echo SW_PORT_SERVER=$SW_PORT_SERVER

	exit -1
fi

pushd openvswitch
. topo.sh
. mcast_snoop.sh
popd

